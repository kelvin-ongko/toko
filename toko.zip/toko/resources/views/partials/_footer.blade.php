  <!-- ======= Footer ======= -->
  <footer id="footer">

    @yield('footer')

    <div class="container">
      <div class="copyright">
        <!-- &copy; Copyright <strong><span> </span></strong>. All Rights Reserved -->
      </div>
      <!-- <div class="credits">
        Designed by 
      </div> -->
    </div>
  </footer><!-- End Footer -->
  @yield('backtop')