  <!-- Vendor CSS Files -->
  <link href="<?php echo e(URL::asset('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(URL::asset('assets/vendor/animate.css/animate.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(URL::asset('assets/vendor/icofont/icofont.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(URL::asset('assets/vendor/aos/aos.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(URL::asset('assets/vendor/datatables/css/jquery.dataTables.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(URL::asset('assets/vendor/select2/css/select2.min.css')); ?>" rel="stylesheet">
  
  <!-- Template Main CSS File -->
  <link href="<?php echo e(URL::asset('assets/css/style.css')); ?>" rel="stylesheet"><?php /**PATH C:\xampp\htdocs\toko\resources\views/partials/_css.blade.php ENDPATH**/ ?>