  <!-- ======= Footer ======= -->
  <footer id="footer">

    <?php echo $__env->yieldContent('footer'); ?>

    <div class="container">
      <div class="copyright">
        <!-- &copy; Copyright <strong><span> </span></strong>. All Rights Reserved -->
      </div>
      <!-- <div class="credits">
        Designed by 
      </div> -->
    </div>
  </footer><!-- End Footer -->
  <?php echo $__env->yieldContent('backtop'); ?><?php /**PATH C:\xampp\htdocs\toko\resources\views/partials/_footer.blade.php ENDPATH**/ ?>