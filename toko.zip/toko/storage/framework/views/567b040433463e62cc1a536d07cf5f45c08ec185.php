@php

@endofphp
<?php /**PATH C:\xampp\htdocs\toko\resources\views/printtransaction.blade.php ENDPATH**/ ?>