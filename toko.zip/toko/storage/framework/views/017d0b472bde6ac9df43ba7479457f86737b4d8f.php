  <!-- Vendor JS Files -->
  <script src="<?php echo e(URL::asset('assets/vendor/jquery/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/vendor/jquery.easing/jquery.easing.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/vendor/php-email-form/validate.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/vendor/waypoints/jquery.waypoints.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/vendor/counterup/counterup.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/vendor/aos/aos.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/vendor/select2/js/select2.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/vendor/datatables/js/dataTables.bootstrap4.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/vendor/chartjs/chart.js')); ?>"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo e(URL::asset('assets/js/main.js')); ?>"></script>

  <?php /**PATH C:\xampp\htdocs\toko\resources\views/partials/_script.blade.php ENDPATH**/ ?>