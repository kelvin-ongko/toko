  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo $__env->yieldContent('title'); ?></title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="<?php echo e(URL::asset('assets/img/favicon.png')); ?>" rel="icon">

  <?php echo $__env->yieldContent('style'); ?><?php /**PATH C:\xampp\htdocs\toko\resources\views/partials/_head.blade.php ENDPATH**/ ?>